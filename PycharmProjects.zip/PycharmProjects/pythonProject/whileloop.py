#while loop for printing 1 to 5 numbers
num=1
while(num<=5):
    print(num)
    num+=1
