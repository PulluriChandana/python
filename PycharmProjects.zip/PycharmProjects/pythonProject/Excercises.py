def integer_to_string(name):
    return str(name)
integer_output=input("Enter a number:")
string_output=integer_to_string(integer_output)
print("String representation:",string_output)