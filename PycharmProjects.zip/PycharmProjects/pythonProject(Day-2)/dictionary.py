#creating a dictinary
student={
    "Name":"P.Chandana",
    "Age":20,
    "CGPA":8.2,
    "Major":"Information Technology"
}

#Accessing the elements in dictinary
print("Name:",student["Name"])
print("Age:",student["Age"])

#checking if the key is present or not
print("Is 'major' is present in dictionary?:",'Major' in student)
print("Is 'computer' present in dictionary?:",'computer' in student)


#printing the keys
print("Keys in student:")
for key in student:
    print(key)

#printing the values
print("Values in student:")
for value in student.values():
    print(value)

#modifying the key
student["University"]="Osmania University"
print("After modifying:",student)

#modifying the value
student["CGPA"]=8.00
print("After changing the cgpa:",student)

#looping through both keys and values
print("Printing the whole dictionary:")
for key,value in student.items():
    print("Key:",key,"value:",value)

#length of dictinonary
dict_length=len(student)
print("Length of a dictionary is:",dict_length)
