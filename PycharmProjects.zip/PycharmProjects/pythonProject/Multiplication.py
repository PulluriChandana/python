def multiplication(number,rows=10):
    for i in range(1,rows+1):
        print(f"{number}x{i}={number * i}")

number=5
multiplication(number)