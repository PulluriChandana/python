num1=10
num2=2

Sum_result=num1+num2
print("Sum:",Sum_result)

Sub_result=num1-num2
print("Sub:",Sub_result)

Mul_result=num1*num2
print("Mul:",Mul_result)

Div_result=num1/num2
print("Div:",Div_result)

Div_result1=num1//num2
print("Floor Divison:",Div_result1)

Mod_result=num1%num2
print("Mod:",Mod_result)

Exp_result=num1**num2
print("Exponential:",Exp_result)
