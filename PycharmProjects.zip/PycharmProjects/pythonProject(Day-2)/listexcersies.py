numbers=[1,2,34,56,23,12,56,78]
numbers1=[75,34,2,3,6,8,1,26]
#Concate a list
numbers3=numbers+numbers1
print("Concatination of a lists:",numbers3)

#Reverse a list
numbers.reverse()
print("Revers of a list:",numbers)

#copy a list
print("Original list:",numbers1)
numbers1.copy()
print("Copying a list:",numbers1)


#sort a list in ascending order
numbers3.sort()
print("Sorting the elements in ascending order:",numbers3)
