#using a for loop for list comprehension of square of a numbers
numbers=[1,2,3,4,5]
squares=[num**2 for num in numbers]
print("Squares:",squares)
