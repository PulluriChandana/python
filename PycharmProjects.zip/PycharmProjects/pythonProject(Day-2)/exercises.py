employee={
    "id":1,
    "Name":"Chandana",
    "Role":"ASE"
}
for key,value in employee.items():
    print("Key:",key,"value:",value)

#print the key-value pair
for key,value in employee.items():
    print("Key:",key,"value:",value)

#Adding a key-value pair
employee["Technolgy"]="Dot net"
for key,value in employee.items():
    print("Key:",key,"value:",value)


#modifying an element
employee["Role"]="SE"
print("Modified element:",employee)

#removing an element
employee_removed=employee.pop("Role")
print("Removed key-value pair",employee_removed)


#length of a dictionary
dict_length=len(employee)
print("Dictionary length:",dict_length)


