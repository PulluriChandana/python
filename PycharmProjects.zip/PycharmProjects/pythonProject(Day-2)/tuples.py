colors=("Red","Blue","Green","Orange")

#Accessing an element in tuples
print("First element:",colors[0])
print("Last elemenr:",colors[-1])


#length of a tuple
tuple_length=len(colors)
print("Length of a tuple:",tuple_length)

#looping through tuples
print("Tuples:")
for i in colors:
    print(i)
