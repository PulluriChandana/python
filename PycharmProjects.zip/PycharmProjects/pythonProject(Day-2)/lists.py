#printing a numbers in a list
numbers=[1,2,3,4,5]
print("List of a numbers:")
for num in numbers:
    print(num)
#accessing elements in a list
print("Fisrt element:",numbers[0])
print("Last element:",numbers[-1])

#Slicing elements in a list
print("Slicing [1:3]",numbers[1:4])
print("Slicing [:3]",numbers[:3])
print("Slicing [2:]",numbers[2:])

#modifying a list
numbers[0]=10
numbers[4]=40
print("After modifying:",numbers)

#appending a element into a list
numbers.append(6)
numbers.append(8)
print("After appending:",numbers)

#removing an element
remove_element=numbers.pop(3)
print("Removed element is:",remove_element)

#length of a list
len_list=len(numbers)
print("Length of a list:",len_list)

#loop in a list
print("Printing a list:")
for num in numbers:
    print(num)
