#function
def greet(name):
    if len(name)>5:
        print("Hello",name)
        print("Nice to meet you")
    else:
        print("Hi there",name)
        print("Short and sweet")

#calling functions
greet("Chandana")
greet("chand")
