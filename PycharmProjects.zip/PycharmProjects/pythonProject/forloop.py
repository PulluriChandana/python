for num in range(1,6):
    print(num)
