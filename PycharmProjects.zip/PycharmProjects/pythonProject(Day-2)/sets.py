#creating a sets
fruits={"apple","banana","Grapes"}
print("Original list:",fruits)

#adding another an element to it
fruits.add("Jack fruit")
print("After adding an element to it:",fruits)

#removing an element from a sets
fruits.remove("apple")
print("After removing an element from sets:",fruits)

#length of a sets
set_length=len(fruits)
print("Length of a sets:",set_length)

#checking the element is present or not
print("Is 'grapes' is present?",'Grapes' in fruits)
print("Is 'apples' is present?",'apples' in fruits)

#looping through sets
print("Fruit Sets:")
for i in fruits:
    print(i)