user_input=''
while user_input!='quit':
    user_input=input("Enter a command:('quit to exit')")
    print("You entered:",user_input)

